#!/bin/sh
python Server.py 5900
